Note : make sure you have the java 8 or above installed in  you computer
step-1 : open the command prompt or terminal
step-2 : go to the unzipped folder where springboot.jpa.restful.crud-1.0.jar reside, you can use "cd" command for this
step-3 : run the application using below command 
java -jar springboot.jpa.restful.crud-1.0.jar  --spring.config.location=file:///application.properties
step-4 : open the browser and hit this url
http://localhost:8999/swagger-ui.html
step-5 : click on the link "Employee CRUD Operation" to see all rest api related to crud operation
step-6 : start doing the manual testing, refer rest-api-crud-operation-testing.pdf
step-7 : now you can start writing the rest api automation testing using rest-assured

 
